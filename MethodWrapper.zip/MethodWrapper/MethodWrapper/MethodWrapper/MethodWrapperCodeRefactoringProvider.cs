using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CodeActions;
using Microsoft.CodeAnalysis.CodeRefactorings;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.CodeAnalysis.Rename;
using Microsoft.CodeAnalysis.Text;
using System;
using System.Collections.Generic;
using System.Composition;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace MethodWrapper
{
    [ExportCodeRefactoringProvider(LanguageNames.CSharp, Name = nameof(MethodWrapperCodeRefactoringProvider)), Shared]
    internal class MethodWrapperCodeRefactoringProvider : CodeRefactoringProvider
    {
        public sealed override async Task ComputeRefactoringsAsync(CodeRefactoringContext context)
        {
            var root = await context.Document.GetSyntaxRootAsync(context.CancellationToken).ConfigureAwait(false);

            var node = root.FindNode(context.Span);

            var methodDecl = node as MethodDeclarationSyntax;
            if (methodDecl == null)
            {
                return;
            }

            var action = CodeAction.Create("Try Catch Log", c => WrapBodyAsync(context.Document, methodDecl, c));

            context.RegisterRefactoring(action);
        }

        string template = @"
            try
            {

            }
            catch(Exception ex)
            {
                Logger.Log($""{nameof($methodname$)}: {ex.Message}"");
            }
";
        private async Task<Solution> WrapBodyAsync(Document document, MethodDeclarationSyntax methodDecl, CancellationToken cancellationToken)
        {
            var originalSolution = document.Project.Solution;

            var methodName = methodDecl.Identifier.Text;

            //var semanticModel = await document.GetSemanticModelAsync(cancellationToken);
            //var typeSymbol = semanticModel.GetDeclaredSymbol(methodDecl, cancellationToken);
            // var optionSet = originalSolution.Workspace.Options;

            var filledTemplate = template.Replace("$methodname$", methodName);

            var comp = CSharpSyntaxTree.ParseText(filledTemplate);
            if (comp == null) return originalSolution;

            var tr = comp.GetRoot().DescendantNodes().OfType<TryStatementSyntax>().FirstOrDefault();
            if (tr == null) return originalSolution;

            TryStatementSyntax newtry = tr;

            //here we assume the try block is empty and no stmtMERGING!
            if (methodDecl.Body.Statements.Count > 0)
            {
               newtry = tr.WithBlock(tr.Block.WithStatements(methodDecl.Body.Statements));
            }
           
            var stmtList = new SyntaxList<StatementSyntax>(newtry);

            var root = await document.GetSyntaxRootAsync(cancellationToken);

            var newroot = root.ReplaceNode(methodDecl.Body, methodDecl.Body.WithStatements(stmtList));

            return originalSolution.WithDocumentSyntaxRoot(document.Id, newroot);
        }

    }
}
